package com.data4life.code.challenge.constant;

public interface FileConstants {
    String SECURE_LOCATION = "/usr/local/mysql-8.0.23-macos10.15-x86_64/include/mysql";
    String FILE_NAME = "tokenData.txt";
}
